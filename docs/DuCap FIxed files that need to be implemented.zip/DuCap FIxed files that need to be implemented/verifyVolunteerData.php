/**
	 *	Verify the data for a volunteer and either add to system or update.
	 *	@param {assoc array}	data	Data entered in form
	 *										key = field ('last_name')
	 *										value = data ('Bird')
	 *	@param {string}			action	"insert" or "update"
	 *	@return {int}				volunteer ID or -1 if there was an error.
	 */

	 function verifyVolunteerData($data, $action) {
	 	$conn = $this->connect();
		
		$out = "";	// Will hold the resulting output.

		// Arrays used for processing.
		$blank_array = array();	// Holds the name of any blank fields.
		$bad_format = array();	// Holds the name of any unacceptable fields.
		$good_data = array();	// Holds the sanitized data.

		// Array of each field in the Volunteers table and its label
		$labels_vol = array("volunteer_id"=>"ID", "last_name"=>"Last Name", "first_name"=>"First Name", "date_of_birth"=>"Date of Birth", "address"=>"Address", "city"=>"City", "state"=>"State", "zip_code"=>"Zip Code", "home_number"=>"Home Number", "work_number"=>"Work Number", "mobile_number"=>"Mobile Number", "email"=>"Email", "site_id"=>"Site ID", "password"=>"Password", "username"=>"Username");

		// Check data submitted to form.
		foreach ($data as $field => $value) {
			
			// Check for blanks for required fields.
			if (!isset($value) && ($field != 'home_number') && ($field != 'work_number')) {
				array_push($blank_array, $field);
				
			} else if ((($field == "last_name") || $field == ("first_name") || ($field == "city") || ($field == "state") && !preg_match("/^[A-Za-z.' -]{1,50}$/", $value)) {
				// Check that text input boxes for names only accept 1-50 letters.
				array_push($bad_format, $field);
				
			} else if($field == "date_of_birth") {
				
				if (!preg_match("/^[0-9]{4}[-][01][0-9][-][0123][0-9]$/", $value))
					array_push($bad_format, $field);
				
				
			} else if(($field == "mobile_number") && !preg_match("/^[0-9)( -]{7,20}(([xX]|(ext)|(ex))?[ -]?[0-9]{1,7})?$/", $value)) {
				
				array_push($bad_format, $field);
				
			}
		}

		// If any fields are not acceptable, display error.
		if (@sizeof($blank_array) > 0) {
			$out = "<p>You didn't fill in one or more of the required fields. Please fill out:<br />";
			
			foreach($blank_array as $value)
				$out .= "- $labels_par[$value]<br />";
			
		} else if (@sizeof($bad_format) > 0) {
			
			$out = "One or more fields has information that appears to be incorrect. Please correct the format for:<br />";
			
			foreach($bad_format as $value)
				$out .= "- $labels_par[$value]<br />";

		} else {
			
			// Sanitize and copy data to a new array.
			foreach ($data as $field => $value) {
				
				$good_data[$field] = strip_tags(trim($data[$field]));
				
				// Get rid of any punctuation in phone number.
				if (($field == "home_number") || ($field == "work_number") || ($field == "mobile_number")) {

					$good_data[$field] = preg_replace("/[)(.-]/", "", $good_data[$field]);
				}
				
				$good_data[$field] = $conn->real_escape_string($good_data[$field]);
			}

			/*
			echo "<br /><br />NEW DATA:<br />";
			foreach ($good_data as $field => $value)
				echo "$field $value<br />";
			*/
		
			// Build query string based on the desired action.
			if ($action == "insert") {
				
				// Search Volunteers table first to make sure Volunteer is not already registered!
				if ($this->getVolunteerID($good_data['last_name'], $good_data['first_name'], $good_data['site_id']) == -1) {

					$qryStr = "INSERT INTO Volunteers (";
					
					// Add fields from form if they match up with Volunteer fields.
					foreach ($good_data as $field => $value) {
						if (array_key_exists($field, $labels_par))
							$qryStr .= "$field,";
					}
					// Remove the comma added after the last field.
					$qryStr[strlen($qryStr) - 1] = ")";
					
					// Add values.
					$qryStr .= " VALUES (";
					foreach ($good_data as $field => $value) {
						
						if (array_key_exists($field, $labels_par)) {
							if ($field == 'site_id')
								// Int fields have no parentheses.
								$qryStr .= " $value,";
							else
								$qryStr .= " '$value',";
						}
					}
					// Remove the comma added after the last value.
					$qryStr[strlen($qryStr) - 1] = ")";

					//prepare statement to prevent injection attacks
					$stmt = $conn->prepare($qryStr);//prepare the statement
					
					//bind parameters
					$stmt->bind_param("ssssssssssssssss",$good_data["volunteer_id"],$good_data["last_name"],$good_data["first_name"],$good_data["date_of_birth"],$good_data["address"],$good_data["city"],$good_data["state"],$good_data["zip_code"],$good_data["home_number"],$good_data["work_number"],$good_data["mobile_number"],$good_data["email"],$good_data["site_id"],$good_data["password"],$good_data["username"]);

					//execute the statement
					$result = $stmt->execute() or die ("ERROR: Could not add new Volunteer!");
					
					//close the statement.
					$stmt->close();
					$conn->close();
					if ($result)
						$out = "Information successfully updated for " . $good_data['first_name'] . " " . $good_data['last_name'] . ".";

					} else {
					
					$out = "Error: Volunteer named $fname $lname is already registered!<br /><br />";
					
					}

				} else if ($action == "update") {
				
					// Build query string to update row in Volunteers table.
					$qryStr = "UPDATE Volunteers SET";
					foreach ($good_data as $field => $value) {
					
						if (($field == 'volunteer_id') || ($field == 'submission'))
							$qryStr .= "";
						else if ($field == 'site_id')
							$qryStr .= " $field=$value,";
						else
							$qryStr .= " $field='$value',";
				}
				
					// Remove the comma added after the last pair.
					$qryStr[strlen($qryStr) - 1] = " ";
				
					$qryStr .= "WHERE volunteer_id=" . $good_data['participant_id'] . ";";
				
					//echo "<br />$qryStr<br /><br />";
								
				
				//prepare statement to prevent injection attacks
				$stmt = $conn->prepare($qryStr);//prepare the statement		

				//bind parameters
				$stmt->bind_param("ssssssssssssssss",$good_data["volunteer_id"],$good_data["last_name"],$good_data["first_name"],$good_data["date_of_birth"],$good_data["address"],$good_data["city"],$good_data["state"],$good_data["zip_code"],$good_data["home_number"],$good_data["work_number"],$good_data["mobile_number"],$good_data["email"],$good_data["site_id"],$good_data["password"],$good_data["username"]);

				//execute the statement
				$result = $stmt->execute() or die ("ERROR: Could not update information for Volunteer!");
				//close the statement.
				$stmt->close();
				$conn->close();
				
				if ($result)
					$out = "Information successfully updated for " . $good_data['first_name'] . " " . $good_data['last_name'] . ".";
				
				} else {
				
					$out = "ERROR: Cannot $action the data.";
			}
			
		}
		
		echo $out;
		
		// Return volunteer ID or -1 if there was an error.
		return $this->getVolunteerID($good_data['last_name'], $good_data['first_name'], $good_data['site_id']);
	}
	





