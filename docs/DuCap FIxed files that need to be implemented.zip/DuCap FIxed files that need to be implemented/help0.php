<html>
<head>
	<title>Help</title>
</head>

<body>
<center>
<?php
	/*
		A reformatted replacement file for help.txt
	*/
	include 'classes/DB.class.php';
	include('helpHeader.php');
	// Connect to database.
	$db = new DB();
?>

<!-- Content -->
<div class = "container header">
	<center><h2>Help</h2></center>
	<br/>
	
</div>
<?php
$selection = $_POST["selection"];

?>
To  <b><?php echo $selection; ?></b><br>
<?php
if($selection == "Register as a Volunteer"){
	echo "1. Go to main site", "<br>"; 
	echo "2. Click Volunteer Registration","<br>";
	echo "3. Fill out form and submit", "<br>";
}
if($selection == "Register a Child as a Volunteer"){
	echo "1. Go to main site", "<br>"; 
	echo "2. Click Child Registration","<br>";
	echo "3. Fill out form and submit", "<br>";
}
if($selection == "View Sites and Events"){
	echo "1. Go to main site", "<br>"; 
	echo "2. Click Sites and Events","<br>";
}
if($selection == "View Attendance"){
	echo "1. Go to main site", "<br>"; 
	echo "2. Click Admin Login","<br>";
	echo "3. Login", "<br>";
	echo "4. Click on Attendance", "<br>";
	echo "5. Use website features", "<br>";
}
if($selection == "Access Staff Control Panel"){
	echo "1. Go to main site", "<br>"; 
	echo "2. Click Admin Login","<br>";
	echo "3. Login", "<br>";
	echo "4. Click on feature to manage", "<br>";
}
?>

<br /> <center> <a href = "help.php">Help</a></center>
	<br /> <br /> <center>&copy; 2017 DuCap	</center>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>
</center>
</body>
</html>