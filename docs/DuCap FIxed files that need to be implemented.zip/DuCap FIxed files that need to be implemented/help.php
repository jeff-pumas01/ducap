<html>
<head>
	<title>Help</title>
</head>

<body>
<center>
<?php
	/*
		A reformatted replacement file for help.txt
	*/
	include 'classes/DB.class.php';
	include('helpHeader.php');
	// Connect to database.
	$db = new DB();
?>

<!-- Content -->
<div class = "container header">
	<center><h2>Help</h2></center>
	<br/>
	
</div>

<form action="help0.php" method="post">

I trying to
<select name="selection">
  <option value=""></option>
  <option value="Register as a Volunteer">Register as a Volunteer</option>
  <option value="Register a Child as a Volunteer">Register a Child as a Volunteer</option>
  <option value="View Sites and Events">View Sites and Events</option>
  <option value="View Attendance">View Attendance</option>
  <option value="Access Staff Control Panel">Access Staff Control Panel</option>
  
</select>

<input type="submit">
</form>

<br /> <center> <a href = "help.php">Help</a></center>
	<br /> <br /> <center>&copy; 2017 DuCap	</center>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>

</center>
</body>
</html>